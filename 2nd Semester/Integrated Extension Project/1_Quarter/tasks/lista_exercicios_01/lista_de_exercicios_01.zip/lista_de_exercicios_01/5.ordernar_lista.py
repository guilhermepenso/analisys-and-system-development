# Nome: Guilherme Penso
# R.A.: 2320311

# 5. Ordenar Lista
# Escreva um programa que peça ao usuário para inserir uma lista de números e então a ordene em ordem crescente.

list = []

list.append(input("Digite o 1° número: "))
list.append(input("Digite o 2° número: "))
list.append(input("Digite o 3° número: "))
list.append(input("Digite o 4° número: "))
list.append(input("Digite o 5° número: "))

print(sorted(list))