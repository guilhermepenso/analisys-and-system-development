# Nome: Guilherme Penso
# R.A.: 2320311

# 1. Inverter String
# Escreva um programa que peça ao usuário para inserir uma string e então a imprima invertida.

entrada = input("Digite uma string: ")[::-1]
print(entrada)

