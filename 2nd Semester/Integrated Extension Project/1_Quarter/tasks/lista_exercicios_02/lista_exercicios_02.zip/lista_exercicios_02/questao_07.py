# Nome: Guilherme Penso
# R.A.: 2320311

# Questão 7

a = True
b = False
print("a E b :", a and b)
print("a OU b :", a or b)

v1 = 5
v2 = 6

print((v1 == v2) and (v1 != v2))
print((v1 == v2) or (v1 != v2))