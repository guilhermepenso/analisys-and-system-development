# Nome: Guilherme Penso
# R.A.: 2320311

# Questão 14

mensagem = "Centro Universitario Unidombosco"
print(len(mensagem.upper()))