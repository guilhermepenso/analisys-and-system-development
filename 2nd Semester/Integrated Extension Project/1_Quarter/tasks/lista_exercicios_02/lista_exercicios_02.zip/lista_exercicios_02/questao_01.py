# Nome: Guilherme Penso
# R.A.: 2320311

# Questão 1

import math

valor_a = int(input("Informe valor A: "))
valor_b = int(input("Informe valor B: "))
print(math.pow(valor_a, 2))
print(math.sqrt(valor_b))
