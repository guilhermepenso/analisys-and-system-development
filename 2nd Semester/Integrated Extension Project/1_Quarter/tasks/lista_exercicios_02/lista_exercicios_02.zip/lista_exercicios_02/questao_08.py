# Nome: Guilherme Penso
# R.A.: 2320311

# Questão 8

my_list = [1, 2, 3]
my_list.append(4)
my_list.remove(2)
print(my_list)