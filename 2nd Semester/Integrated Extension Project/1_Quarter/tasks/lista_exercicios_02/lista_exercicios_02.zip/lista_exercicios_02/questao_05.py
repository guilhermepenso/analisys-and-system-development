# Nome: Guilherme Penso
# R.A.: 2320311

# Questão 5

arquivo = open("meu_arquivo.txt", "a")