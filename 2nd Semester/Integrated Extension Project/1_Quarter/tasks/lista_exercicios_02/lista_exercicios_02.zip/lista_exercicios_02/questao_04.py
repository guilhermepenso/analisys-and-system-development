# Nome: Guilherme Penso
# R.A.: 2320311

# Questão 4

valores = []
for i in range (1, 16):
    if i % 2 != 0:
        valores.append(i)
print(valores)