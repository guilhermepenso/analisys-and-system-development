# Nome: Guilherme Penso
# R.A.: 2320311

# Questão 10

x = 10
if x > 5:
    print("A")
elif x < 15:
    print("B")
else:
    print("C")